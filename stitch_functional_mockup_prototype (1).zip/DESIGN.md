---
name: MediDesk Aura
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#c2c6d4'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#8c919e'
  outline-variant: '#424752'
  surface-tint: '#aac7ff'
  primary: '#aac7ff'
  on-primary: '#002f65'
  primary-container: '#4f90f3'
  on-primary-container: '#002958'
  inverse-primary: '#005cb9'
  secondary: '#a5e7ff'
  on-secondary: '#003543'
  secondary-container: '#00d2ff'
  on-secondary-container: '#00566a'
  tertiary: '#b1c6fb'
  on-tertiary: '#182f5b'
  tertiary-container: '#7b90c2'
  on-tertiary-container: '#0f2854'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d7e3ff'
  primary-fixed-dim: '#aac7ff'
  on-primary-fixed: '#001b3e'
  on-primary-fixed-variant: '#00458e'
  secondary-fixed: '#b6ebff'
  secondary-fixed-dim: '#47d6ff'
  on-secondary-fixed: '#001f28'
  on-secondary-fixed-variant: '#004e60'
  tertiary-fixed: '#d9e2ff'
  tertiary-fixed-dim: '#b1c6fb'
  on-tertiary-fixed: '#001a43'
  on-tertiary-fixed-variant: '#304673'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
  surface-card: '#0e1014'
  accent-light-cyan: '#A4F4FD'
  accent-dark-navy: '#091020'
  success: '#28c840'
  warning: '#febc2e'
  danger: '#ff5f57'
  glass-fill: rgba(255, 255, 255, 0.01)
typography:
  hero-h1:
    fontFamily: Inter
    fontSize: 80px
    fontWeight: '600'
    lineHeight: '0.9'
    letterSpacing: -0.03em
  hero-h1-mobile:
    fontFamily: Inter
    fontSize: 42px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: -0.03em
  section-h2:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.02'
    letterSpacing: -0.02em
  section-h2-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0em
  card-title:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0em
  nav-link:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.0'
    letterSpacing: 0em
  label-small:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.0'
    letterSpacing: 0em
  eyebrow:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.0'
    letterSpacing: 0.1em
  tv-token:
    fontFamily: Inter
    fontSize: 180px
    fontWeight: '800'
    lineHeight: '1.0'
    letterSpacing: 0em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1152px
  nav-height: 64px
  menu-height: 40px
  section-gap: 80px
  grid-gap: 64px
  container-pad: 24px
  card-pad: 20px
  button-pad: 12px 20px
---

## Brand & Style

The design system embodies a **Premium Medical-Tech** aesthetic, moving away from sterile clinical whites toward a **Cinematic Dark-Mode** experience. It is designed to evoke feelings of high-precision, cutting-edge intelligence, and professional calm.

The visual narrative is built on **Glassmorphism** and **Layered Depth**. It utilizes semi-transparent "liquid-glass" surfaces, backdrop blurs, and subtle inner glows to create a sense of sophisticated machinery. The style is heavily influenced by high-end hardware interfaces (NVIDIA/Apple), focusing on high-fidelity details like shimmering borders, noise-textured typography, and smooth, staggered motion. This is a system for high-performance medical environments where data clarity meets executive-level polish.

## Colors

The palette is anchored by a deep obsidian background (`#0c0c0c`), providing a canvas for high-contrast chromatic accents. 

- **Primary Blue (#3D81E3):** Used for essential brand touchpoints, unread indicators, and primary user-driven actions.
- **Cyan Highlight (#00d2ff):** Represents AI intelligence, active system statuses, and technological "pulses" within the UI.
- **Surface Strategy:** Backgrounds utilize layered transparencies. Primary panels use `#0e1014`, while floating glass components use a highly transparent white tint (`rgba(255, 255, 255, 0.01)`) to enable backdrop-blur effects.
- **Typography:** Text levels are strictly defined by opacity rather than hex shifts, ranging from pure white (`#ffffff`) for headings to `rgba(255, 255, 255, 0.40)` for secondary metadata.

## Typography

This design system uses **Inter** exclusively to maintain a systematic, utilitarian, and modern technical feel. 

Headlines utilize aggressive negative letter-spacing and tight line-heights to create a "cinematic" impact. For hero sections, a "Shiny" animated gradient should be applied to the text, moving from `-200%` to `200%` background-position over 6 seconds.

**Antialiasing:** All typography must use `-webkit-font-smoothing: antialiased` to preserve legibility against the dark background. Large display numbers (TV Token) should incorporate a pulse animation to draw attention in high-traffic clinic areas.

## Layout & Spacing

The layout is governed by a **fixed-width centered grid** (1152px) with generous vertical breathing room. 

- **Grid System:** A standard 12-column grid is used, but layout blocks are primarily organized in 2-column or 3-column spans with a significant 64px horizontal gap to emphasize distinction between clinical data modules.
- **Vertical Rhythm:** Major sections are separated by 80px gaps. Internal dashboard elements use 20-24px padding.
- **Mobile Adaptivity:** On mobile devices, the 64px grid gaps collapse to 24px, and section padding is reduced to 48px. All cards reflow to a single-column stack.
- **Structural Guides:** 1px vertical lines (`rgba(255, 255, 255, 0.10)`) should be placed at the container edges to reinforce the architectural feel of the application.

## Elevation & Depth

Hierarchy is established through **Backdrop Blur** and **Physical Light Simulation** rather than traditional drop shadows.

- **Liquid Glass:** Cards use `backdrop-filter: blur(4px)` combined with a subtle white fill (`rgba(255,255,255,0.01)`).
- **Shimmer Borders:** Every card features a 1.4px faux-border created with a linear gradient (180deg) from 45% white to transparent, simulating a "top-down" light source hitting the glass edge.
- **Inner Depth:** An inset shadow of `inset 0 1px 1px rgba(255,255,255,0.10)` provides a tactile ridge to buttons and inputs.
- **Environmental Lighting:** Large radial gradients (Hero Glow) should be placed behind primary content areas to create a "spotlight" effect on the Obsidian background.

## Shapes

The shape language is sophisticated and variable, used to distinguish between different types of interaction:

- **Dashboard Containers:** 16px radius for the main application wrapper.
- **Standard Cards:** 20px to 24px radius to create a soft, accessible feel for medical data.
- **Premium/Pricing Cards:** 44px radius for a highly stylized, high-end consumer look.
- **Action Elements:** Pill-shaped (100px) for all buttons, search inputs, and toggles, referencing modern OS design patterns.
- **Status Indicators:** Precise 6px or 8px perfect circles for doctor availability and unread notifications.

## Components

- **Buttons:** 
    - *Primary:* Pill-shaped, white background with black text (Apple-style) for maximum contrast.
    - *Ghost:* Pill-shaped, transparent with a `rgba(255,255,255,0.10)` border and white text.
- **Liquid-Glass Cards:** Must include the 4px blur, the 1.4px shimmer border, and the 20-24px corner radius.
- **Inputs:** Search bars and text fields must be pill-shaped with a `rgba(255,255,255,0.05)` background and a placeholder opacity of 35%.
- **Avatars:** 36x36px for clinicians, utilizing a gradient fill (`#00d2ff` to `#0B2551`). AI avatars are smaller (28px) with a dedicated Sparkle icon.
- **Navigation:** A global 64px header with a secondary 40px "macOS-style" menu strip below it for utility actions.
- **Status Dots:** Use the semantic palette: Green (#28c840) for Available, Amber (#febc2e) for Pending/Break, and Red (#ff5f57) for Emergency/Busy.
- **TV Mode:** A specialized high-contrast view for large screens featuring the `tv-token` typography and a 2s pulse animation on the ticket numbers.